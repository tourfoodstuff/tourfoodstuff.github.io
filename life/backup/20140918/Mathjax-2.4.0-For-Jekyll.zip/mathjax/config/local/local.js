MathJax.Hub.Register.StartupHook("TeX Jax Ready",function () {
  var TEX = MathJax.InputJax.TeX;
});
MathJax.Ajax.loadComplete("[MathJax]/config/local/local.js");
